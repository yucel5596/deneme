-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 21, 2013 at 08:31 PM
-- Server version: 5.5.31
-- PHP Version: 5.4.4-14+deb7u3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `website`
--

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(150) NOT NULL,
  `views` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `title`, `views`) VALUES
(1, 'The .net strip #24: Abandon shopping cart!', 0),
(2, 'An introduction to Lean', 0),
(3, 'Build a 360 view image slider with JavaScript', 0),
(4, 'Don''t rely too much on JavaScript libraries', 0),
(5, 'Social media at SXSWi: the top five talking points', 0),
(6, 'Get more out of your CSS transitions with JQery', 0),
(7, 'The Agile Waterfall', 0),
(8, 'The developer''s guide to new exciting web technologies', 0),
(9, 'The .net strip #23: Streamlining our process', 0),
(10, 'Five killer ways to use maps', 0),
(11, 'Josh Brewer on inspiration', 0),
(12, 'JavaScript debugging for beginners', 0),
(13, 'Building user trust', 0),
(14, 'The top 12 ExpressionEngine add-ons', 0),
(15, 'Jarod Spool on usability and intuitive design', 0),
(16, 'What social sharing widget is right for you?', 0),
(17, '50 free web-design tools that rock!', 0),
(18, 'Getting paid on time', 0),
(19, 'inside the CSS WG: Arno Gourdol', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
