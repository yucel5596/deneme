<?php

$titles = array(
	'The .net strip #24: Abandon shopping cart!',
	'An introduction to Lean',
	'Build a 360 view image slider with JavaScript',
	'Don\'t rely too much on JavaScript libraries',
	'Social media at SXSWi: the top five talking points',
	'Get more out of your CSS transitions with JQery',
	'The Agile Waterfall',
	'The developer\'s guide to new exciting web technologies',
	'The .net strip #23: Streamlining our process',
	'Five killer ways to use maps',
	'Josh Brewer on inspiration',
	'JavaScript debugging for beginners',
	'Building user trust',
	'The top 12 ExpressionEngine add-ons',
	'Jarod Spool on usability and intuitive design',
	'What social sharing widget is right for you?',
	'50 free web-design tools that rock!',
	'Getting paid on time',
	'inside the CSS WG: Arno Gourdol',
);

$data = array(
	'id' => 'id',
	'title' => $titles,
	'views' => 'views',
);

$results = array();

$fields_sql = '`' . implode('`, `', array_keys($data)) . '`';

/* Loops through all the names and appends the sql statements to the array
 called results
*/
foreach ($titles as $title) {
	$sql = "
   INSERT INTO `articles` ($fields_sql) VALUES (NULL, '$title');";
	$results[] = $sql;
}

// The output below can be pasted into phpmyadmin
function output ($results) {
	foreach ($results as $result) {
		echo $result . '<br>';
	}
}

output($results);

?>