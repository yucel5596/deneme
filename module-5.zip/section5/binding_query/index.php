<?php

/*
 * There are extra lines of code added to this file, that are used in the
 * lecture.  This code below represents the last point of the video.
 * So uncomment or comment the code respectfully when working through
 * this lecture.
 * Also please change the db setting below to match your config
 */

$config['db'] = array(
    'host' => 'localhost',
    'username' => 'root',
    'password' => 'udemy',
    'dbname' => 'website',
);

$db = new PDO('mysql:host=' . $config['db']['host'] . ';dbname=' . $config['db']['dbname'], $config['db']['username'], $config['db']['password']);
/*$db->prepare("SELECT `articles`.`title` FROM `articles` WHERE `articles`.`title` LIKE '%The%'");
query = $db->prepare("SELECT `articles`.`title` FROM `articles` WHERE `articles`.`title` LIKE '%The%'");

$query->execute();

$rows = $query->fetchAll(PDO::FETCH_ASOC);
echo '<pre>, print_r($rows, true), '</pre>';
*/
$query = $db->prepare("SELECT `articles`.`title`  FROM `articles` WHERE `articles`.`title` LIKE :search");

$search = (isset($_GET['search']) === true) ? $_GET['search'] : '';

$query->bindValue(':search', '%' . $search . '%', PDO::PARAM_STR);

//$query->bindValue(':search', '%The%', PDO::PARAM_STR);

$query->execute();

$rows = $query->fetchAll(PDO::FETCH_ASSOC);
echo '<pre>', print_r($rows, true), '</pre>';

?>