<?php

/*
 * There are extra lines of code added to this file, that are used in the
 * lecture.  This code below represents the last point of the video.
 * So uncomment or comment the code respectfully when working through
 * this lecture.
 * Also please change the db setting below to match your config
 */

$config['db'] = array(
    'host' => 'localhost',
    'username' => 'root',
    'password' => 'udemy',
    'dbname' => 'website',
);

$db = new PDO('mysql:host=' . $config['db']['host'] . ';dbname=' . $config['db']['dbname'], $config['db']['username'], $config['db']['password']);
$query = $db->query("SELECT `articles`.`title`  FROM `articles` LIMIT 6");

while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
    echo $row['title'], '<br>';
}

echo '<p>Returned ', $query->rowCount(), ' results</p>';

// Deleting records in the db
// Uncomment the following code to delete the record from the db
/*$query = $db->query("DELETE FROM `articles` WHERE `articles`.`id` = 20");

echo '<p>Deleted ', $query->rowCount(), ' article</p>';*/
?>