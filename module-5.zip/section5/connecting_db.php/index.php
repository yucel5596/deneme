<?php

// Please change the db settings below to match your config

$config['db'] = array(
    'host' => 'localhost',
    'username' => 'root',
    'password' => 'udemy',
    'dbname' => 'website',
);

$db = new PDO('mysql:host=' . $config['db']['host'] . ';dbname=' . $config['db']['dbname'], $config['db']['username'], $config['db']['password']);
$query = $db->query("SELECT `articles`.`title` FROM `articles`");

while ($row = $query->fetch(PDO::FETCH_ASSOC)) {
    echo $row['title'], '<br>';
}
?>